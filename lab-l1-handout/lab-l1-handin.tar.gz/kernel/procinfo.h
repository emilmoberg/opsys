struct procinfo {
    int pid;                // Process ID
    char name[16];          // Process name
    int state;              // Process state
};
